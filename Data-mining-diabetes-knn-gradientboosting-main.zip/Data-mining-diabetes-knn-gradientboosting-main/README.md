# Data-mining-diabetes-knn-gradientboosting
Repository ini berisi proyek  yang berjudul "Perbandingan Algoritma KNN dan Gradient Boosting untuk Prediksi Penyakit Diabetes". Dalam proyek ini, Kami bertujuan untuk menganalisis performa dua algoritma machine learning, yaitu KNN (K-Nearest Neighbors) dan Gradient Boosting, dalam memprediksi risiko diabetes berdasarkan dataset yang di ambil di Kaggel (https://www.kaggle.com/datasets/vikasukani/diabetes-data-set)

Project Data mining 
Anggota Kelompok
1. Dwi Vandela
2. Cut Zahara
3. Nurul Afdal
4. Indrik Hotniati Berutu
5. Ade Pria Ardiansyah Lembong
